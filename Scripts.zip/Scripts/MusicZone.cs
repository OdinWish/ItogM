using UnityEngine;

public class MusicZone : MonoBehaviour
{
    [Header("Music Settings")]
    public AudioClip zoneMusic;
    public float fadeDuration = 1.5f;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            if (AudioManager.Instance != null && zoneMusic != null)
            {
                AudioManager.Instance.ChangeMusic(zoneMusic, fadeDuration);
            }
        }
    }
}
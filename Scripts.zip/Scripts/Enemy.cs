using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{
    [Header("Respawn & Animation")]
    public float deathAnimDuration = 0.5f;
    public float respawnTime = 2f;

    [Header("Audio Clips")]
    public AudioClip deathSound;

    private Animator animator;
    private Collider2D col;
    private SpriteRenderer sr;
    private Vector3 startPosition;
    private bool isDead = false;

    void Start()
    {
        animator = GetComponent<Animator>();
        col = GetComponent<Collider2D>();
        sr = GetComponent<SpriteRenderer>();
        startPosition = transform.position;
    }

    public void TakeDamage(int damage)
    {
        if (!isDead) Die();
    }

    private void Die()
    {
        isDead = true;
        Debug.Log("���� ��������!");

        if (AudioManager.Instance != null && deathSound != null)
        {
            AudioManager.Instance.PlaySFX(deathSound, true);
        }

        Player player = Object.FindFirstObjectByType<Player>();
        if (player != null)
        {
            player.RechargeDash();
        }

        StartCoroutine(DeathAndRespawn());
    }

    private IEnumerator DeathAndRespawn()
    {
        if (animator != null)
        {
            animator.Play("EnemyDeath");
        }

        yield return new WaitForSeconds(deathAnimDuration);

        ToggleEnemyState(false);

        yield return new WaitForSeconds(respawnTime);

        transform.position = startPosition;
        isDead = false;

        if (animator != null)
        {
            animator.Rebind();
            animator.Update(0f);
        }

        ToggleEnemyState(true);
    }

    private void ToggleEnemyState(bool active)
    {
        if (sr != null)
        {
            Color c = sr.color;
            c.a = active ? 1f : 0f;
            sr.color = c;
        }

        if (col != null)
        {
            col.enabled = active;
        }
    }
}
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SettingsMenu : MonoBehaviour
{
    [Header("Audio UI")]
    public Slider volumeSlider;
    public Slider musicSlider;
    public Slider sfxSlider;

    [Header("Controls UI")]
    public TextMeshProUGUI jumpKeyText;
    public TextMeshProUGUI dashKeyText;
    public TextMeshProUGUI attackKeyText;

    [Header("Warnings (��������������� �����)")]
    public GameObject jumpWarning;
    public GameObject dashWarning;
    public GameObject attackWarning;

    private bool isWaitingForKey = false;
    private string actionToRebind;

    public bool IsWaitingForKey => isWaitingForKey;

    void Start()
    {
        if (volumeSlider != null) volumeSlider.value = PlayerPrefs.GetFloat("MasterVolume", 1f);
        if (musicSlider != null) musicSlider.value = PlayerPrefs.GetFloat("MusicVolume", 1f);
        if (sfxSlider != null) sfxSlider.value = PlayerPrefs.GetFloat("SFXVolume", 1f);

        UpdateKeyLabels();
    }

    void Update()
    {
        if (isWaitingForKey)
        {
            foreach (KeyCode kcode in System.Enum.GetValues(typeof(KeyCode)))
            {
                if (Input.GetKeyDown(kcode))
                {
                    if (kcode == KeyCode.Escape)
                    {
                        CancelRebind();
                        break;
                    }

                    PlayerPrefs.SetString(actionToRebind + "Key", kcode.ToString());
                    isWaitingForKey = false;
                    UpdateKeyLabels();

                    Player p = Object.FindFirstObjectByType<Player>();
                    if (p != null) p.RefreshControls();

                    break;
                }
            }
        }
    }

    public void SetVolume(float volume)
    {
        if (AudioManager.Instance != null) AudioManager.Instance.SetMasterVolume(volume);
    }

    public void SetMusicVolume(float volume)
    {
        if (AudioManager.Instance != null) AudioManager.Instance.SetMusicVolume(volume);
    }

    public void SetSFXVolume(float volume)
    {
        if (AudioManager.Instance != null) AudioManager.Instance.SetSFXVolume(volume);
    }

    public void StartRebind(string actionName)
    {
        isWaitingForKey = true;
        actionToRebind = actionName;

        if (actionName == "Jump") jumpKeyText.text = "...";
        if (actionName == "Dash") dashKeyText.text = "...";
        if (actionName == "Attack") attackKeyText.text = "...";
    }

    public void CancelRebind()
    {
        isWaitingForKey = false;
        UpdateKeyLabels();
    }

    private void UpdateKeyLabels()
    {
        string jKey = PlayerPrefs.GetString("JumpKey", "Space");
        string dKey = PlayerPrefs.GetString("DashKey", "LeftShift");
        string aKey = PlayerPrefs.GetString("AttackKey", "Z");

        if (jumpKeyText != null) jumpKeyText.text = jKey;
        if (dashKeyText != null) dashKeyText.text = dKey;
        if (attackKeyText != null) attackKeyText.text = aKey;

        bool jumpConflict = (jKey == dKey) || (jKey == aKey);
        bool dashConflict = (dKey == jKey) || (dKey == aKey);
        bool attackConflict = (aKey == jKey) || (aKey == dKey);

        if (jumpWarning != null) jumpWarning.SetActive(jumpConflict);
        if (dashWarning != null) dashWarning.SetActive(dashConflict);
        if (attackWarning != null) attackWarning.SetActive(attackConflict);
    }
}
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public GameObject pauseMenuUI;
    public GameObject settingsPanel;
    private SettingsMenu settingsMenuScript;
    private bool isPaused = false;

    void Start()
    {
        settingsMenuScript = GetComponent<SettingsMenu>();
        if (settingsMenuScript == null && settingsPanel != null)
        {
            settingsMenuScript = settingsPanel.GetComponentInChildren<SettingsMenu>();
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (settingsMenuScript != null && settingsMenuScript.IsWaitingForKey)
            {
                settingsMenuScript.CancelRebind();
                return;
            }

            if (settingsPanel != null && settingsPanel.activeSelf)
            {
                settingsPanel.SetActive(false);
                if (pauseMenuUI != null) pauseMenuUI.SetActive(true);
            }
            else
            {
                if (isPaused) Resume();
                else Pause();
            }
        }
    }

    public void Resume()
    {
        if (pauseMenuUI != null) pauseMenuUI.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(false);

        Time.timeScale = 1f;
        isPaused = false;
    }

    void Pause()
    {
        if (pauseMenuUI != null) pauseMenuUI.SetActive(true);
        Time.timeScale = 0f;
        isPaused = true;
    }

    public void LoadMainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }
}
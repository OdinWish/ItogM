using UnityEngine;
using UnityEngine.Audio;
using System.Collections;

public class AudioManager : MonoBehaviour
{
    private static AudioManager _instance;
    public static AudioManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = Object.FindFirstObjectByType<AudioManager>();
                if (_instance == null)
                {
                    Debug.LogError("�� ����� ����������� AudioManager!");
                }
            }
            return _instance;
        }
    }

    [Header("Audio Mixer")]
    public AudioMixer audioMixer;

    [Header("Audio Sources")]
    public AudioSource musicSource1;
    public AudioSource musicSource2;
    public AudioSource sfxSource;

    [Header("All Music Tracks")]
 
    public AudioClip[] allMusicTracks;

    private AudioSource activeMusicSource;
    private Coroutine fadeCoroutine;

    void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);

            AudioSource[] sources = GetComponents<AudioSource>();
            if (sources.Length >= 3)
            {
                if (musicSource1 == null) musicSource1 = sources[0];
                if (musicSource2 == null) musicSource2 = sources[1];
                if (sfxSource == null) sfxSource = sources[2];
            }
        }
        else if (_instance != this)
        {
            Destroy(gameObject);
            return;
        }

        activeMusicSource = musicSource1;
    }

    void Start()
    {
        ApplyChannelVolume("MasterVolume", PlayerPrefs.GetFloat("MasterVolume", 1f));
        ApplyChannelVolume("MusicVolume", PlayerPrefs.GetFloat("MusicVolume", 1f));
        ApplyChannelVolume("SFXVolume", PlayerPrefs.GetFloat("SFXVolume", 1f));

        if (PlayerPrefs.GetInt("LoadFromSave", 0) == 1)
        {
            string savedMusicName = PlayerPrefs.GetString("LastPlayingMusic", "");
            if (!string.IsNullOrEmpty(savedMusicName))
            {
                AudioClip savedTrack = System.Array.Find(allMusicTracks, track => track != null && track.name == savedMusicName);

                if (savedTrack != null)
                {
                    ChangeMusic(savedTrack, 0f);
                }
            }
        }
    }

    private void ApplyChannelVolume(string parameterName, float linearVolume)
    {
        if (audioMixer != null)
        {
            float dB = linearVolume <= 0.0001f ? -80f : Mathf.Log10(linearVolume) * 20f;
            audioMixer.SetFloat(parameterName, dB);
        }
    }

    public void SetMasterVolume(float volume) { ApplyChannelVolume("MasterVolume", volume); PlayerPrefs.SetFloat("MasterVolume", volume); PlayerPrefs.Save(); }
    public void SetMusicVolume(float volume) { ApplyChannelVolume("MusicVolume", volume); PlayerPrefs.SetFloat("MusicVolume", volume); PlayerPrefs.Save(); }
    public void SetSFXVolume(float volume) { ApplyChannelVolume("SFXVolume", volume); PlayerPrefs.SetFloat("SFXVolume", volume); PlayerPrefs.Save(); }

    public void PlaySFX(AudioClip clip, bool pitchShift = true)
    {
        if (clip == null || sfxSource == null) return;
        if (pitchShift) sfxSource.pitch = Random.Range(0.9f, 1.1f);
        else sfxSource.pitch = 1f;
        sfxSource.PlayOneShot(clip);
    }

    public void ChangeMusic(AudioClip newTrack, float fadeDuration = 1.5f)
    {
        if (newTrack == null) return;
        if (activeMusicSource != null && activeMusicSource.clip == newTrack && activeMusicSource.isPlaying) return;

        PlayerPrefs.SetString("LastPlayingMusic", newTrack.name);
        PlayerPrefs.Save();

        if (fadeCoroutine != null) StopCoroutine(fadeCoroutine);
        fadeCoroutine = StartCoroutine(FadeMusicRoutine(newTrack, fadeDuration));
    }

    private IEnumerator FadeMusicRoutine(AudioClip newTrack, float fadeDuration)
    {
        AudioSource oldSource = activeMusicSource;
        AudioSource newSource = (activeMusicSource == musicSource1) ? musicSource2 : musicSource1;

        if (newSource == null) yield break;

        newSource.clip = newTrack;
        newSource.volume = 0f;
        newSource.Play();

        float elapsed = 0f;
        float targetVolume = 1f;
        float startOldVolume = oldSource != null ? oldSource.volume : 0f;

        while (elapsed < fadeDuration)
        {
            elapsed += Time.deltaTime;
            float t = fadeDuration > 0 ? elapsed / fadeDuration : 1f;

            if (oldSource != null && oldSource.isPlaying)
                oldSource.volume = Mathf.Lerp(startOldVolume, 0f, t);

            newSource.volume = Mathf.Lerp(0f, targetVolume, t);

            yield return null;
        }

        if (oldSource != null && oldSource.isPlaying) oldSource.Stop();
        activeMusicSource = newSource;
    }
}
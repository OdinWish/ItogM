using UnityEngine;
using Unity.Cinemachine;

public class CameraShake : MonoBehaviour
{
    public static CameraShake Instance;
    private CinemachineCamera virtualCamera;
    private CinemachineBasicMultiChannelPerlin noise;
    private float shakeTimer;
    private float shakeTimerTotal;
    private float startingIntensity;

    void Awake()
    {
        if (Instance == null) Instance = this;

        virtualCamera = GetComponent<CinemachineCamera>();
        if (virtualCamera != null)
        {
            
            noise = GetComponentInChildren<CinemachineBasicMultiChannelPerlin>();
        }
    }

    public void Shake(float duration, float magnitude)
    {
        if (noise != null)
        {
            noise.AmplitudeGain = magnitude;
            startingIntensity = magnitude;
            shakeTimer = duration;
            shakeTimerTotal = duration;
        }
    }

    void Update()
    {
        if (shakeTimer > 0)
        {
            shakeTimer -= Time.deltaTime;
            if (noise != null)
            {
                noise.AmplitudeGain = Mathf.Lerp(startingIntensity, 0f, 1 - (shakeTimer / shakeTimerTotal));
            }
        }
    }
}
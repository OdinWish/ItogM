using UnityEngine;

public class StoneTriggerZone : MonoBehaviour
{
    public ShakingStone targetStone;

    private bool hasTriggered = false;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!hasTriggered && collision.CompareTag("Player") && targetStone != null)
        {
            targetStone.TriggerFall();
            hasTriggered = true;
        }
    }

    public void ResetTrigger()
    {
        hasTriggered = false;
    }
}
using UnityEngine;

public class Player : MonoBehaviour
{
    [Header("Pogo Settings")]
    public LayerMask pogoLayer;
    public float pogoForce = 12f;

    [Header("Respawn System")]
    private Vector3 currentRespawnPosition;

    [Header("Die Effects")]
    public float blinkDuration = 1.5f;
    public int blinkCount = 6;
    public GameObject deathEffectPrefab;

    [Header("Upgrades")]
    public bool hasDashUnlocked;
    public bool hasDoubleJumpUnlocked;

    [Header("Upgrade Animators")]
    public RuntimeAnimatorController upgradedAnimatorController;

    [Header("Dash Settings")]
    public float dashSpeed = 15f;
    public float dashDuration = 0.2f;
    public GameObject dashEffectPrefab;
    public Vector2 dashEffectOffset = new Vector2(0f, 0f);

    private bool canDash;
    private bool isDashing;
    private float dashTimeLeft;
    private Vector2 dashDirection;

    [Header("Double Jump Settings")]
    public float doubleJumpForce = 10f;
    public float doubleJumpAnimDuration = 0.3f;
    public GameObject doubleJumpEffectPrefab;
    public Vector2 doubleJumpEffectOffset = new Vector2(0f, -0.8f);

    private bool canDoubleJump;
    private bool isDoubleJumping;
    private float doubleJumpAnimTimer;

    [Header("Combat Settings")]
    public int attackDamage = 10;
    public Vector2 attackCapsuleSize = new Vector2(2.5f, 1f);
    public CapsuleDirection2D capsuleDirection = CapsuleDirection2D.Horizontal;
    public LayerMask enemyLayer;
    public Vector2 normalHitboxOffset = new Vector2(1.2f, 0f);
    public Vector2 downHitboxOffset = new Vector2(0f, -1.2f);

    [Header("Attack Settings")]
    public float attackCooldown = 0.4f;
    public float effectDuration = 0.3f;
    private float attackTimer;
    private bool isAttacking;

    [Header("Attack Effects")]
    public GameObject normalAttackPrefab;
    public GameObject downAttackPrefab;
    public Transform normalAttackPoint;
    public Transform downAttackPoint;
    public Vector2 normalAttackOffset = new Vector2(1f, 0f);
    public Vector2 downAttackOffset = new Vector2(0f, -1f);

    [Header("Movement")]
    public float moveSpeed = 5f;
    public float jumpForce = 10f;

    [Header("Advanced Jumping")]
    public float jumpCutMultiplier = 0.5f;
    public float coyoteTime = 0.1f;
    public float jumpBufferTime = 0.15f;

    [Header("Gravity Modifications")]
    public float baseGravity = 1.5f;
    public float fallGravityMultiplier = 1.5f;
    public float maxFallSpeed = 11f;

    private float coyoteTimeCounter;
    private float jumpBufferCounter;

    [Header("Ground Detection")]
    public Transform groundCheck;
    public float groundRadius = 0.1f;
    public LayerMask groundLayer;

    [Header("Wall Jump Settings")]
    public Transform wallCheck;
    public float wallCheckRadius = 0.15f;
    public LayerMask wallLayer;
    public float wallSlidingSpeed = 2f;
    public Vector2 wallJumpForce = new Vector2(5f, 7f);
    public float wallJumpDuration = 0.2f;

    [Header("Moving Wall Support")]
    public float wallStickForce = 10f;

    [Header("Player Audio SFX")]
    public AudioClip jumpSound;
    public AudioClip doubleJumpSound;
    public AudioClip dashSound;
    public AudioClip attackSound;
    public AudioClip pogoSound;
    public AudioClip deathSound;
    public AudioClip landSound;
    public AudioClip wallJumpSound;

    private bool wasGrounded;

    private Rigidbody2D rb;
    private bool isGrounded;
    private Animator animator;
    private SpriteRenderer spriteRenderer;

    private bool isTouchingWall;
    private bool isWallSliding;
    private bool isWallJumping;
    private float wallJumpDirection;
    private float wallJumpTimer;
    private bool isClingingToStone;

    private bool isOnFallingWall;
    private Transform currentFallingWall;
    private Vector3 lastFallingWallPosition;
    private ShakingStone currentStone;
    private Vector3 baseScale;

    private KeyCode jumpKey;
    private KeyCode dashKey;
    private KeyCode attackKey;
    private bool isEndingSequence = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();

        rb.gravityScale = baseGravity;
        wallJumpDirection = 1f;
        baseScale = transform.localScale;

        RefreshControls();

        if (PlayerPrefs.GetInt("LoadFromSave", 0) == 1 && PlayerPrefs.GetInt("HasSave", 0) == 1)
        {
            float x = PlayerPrefs.GetFloat("SaveX");
            float y = PlayerPrefs.GetFloat("SaveY");
            transform.position = new Vector3(x, y, transform.position.z);

            if (PlayerPrefs.GetInt("DashUnlocked", 0) == 1) UnlockDash();
            if (PlayerPrefs.GetInt("DoubleJumpUnlocked", 0) == 1) UnlockDoubleJump();
        }

        currentRespawnPosition = transform.position;
    }

    public void RefreshControls()
    {
        jumpKey = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("JumpKey", "Space"));
        dashKey = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("DashKey", "LeftShift"));
        attackKey = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("AttackKey", "Z"));
    }

    void Update()
    {
        if (isEndingSequence) return;

        CheckWorld();

        if (!wasGrounded && isGrounded && rb.linearVelocity.y <= 0f)
        {
            if (AudioManager.Instance != null && landSound != null)
            {
                AudioManager.Instance.PlaySFX(landSound);
            }
        }

        wasGrounded = isGrounded;

        HandleDash();

        if (isDashing)
        {
            rb.gravityScale = 0f;
            rb.linearVelocity = dashDirection * dashSpeed;
            return;
        }

        if (isDoubleJumping)
        {
            doubleJumpAnimTimer -= Time.deltaTime;
            if (doubleJumpAnimTimer <= 0) isDoubleJumping = false;
        }

        float moveInput = Input.GetAxis("Horizontal");

        HandleAttack();
        UpdateJumpCounters();
        HandleFallingWall(moveInput);
        WallSlideCheck(moveInput);
        WallJumpCheck();

        if (!isWallJumping)
        {
            rb.linearVelocity = new Vector2(moveInput * moveSpeed, rb.linearVelocity.y);

            if (jumpBufferCounter > 0f && coyoteTimeCounter > 0f)
            {
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);

                if (AudioManager.Instance != null && jumpSound != null) AudioManager.Instance.PlaySFX(jumpSound, true);

                jumpBufferCounter = 0f;
                coyoteTimeCounter = 0f;
                isOnFallingWall = false;
            }
            else if (jumpBufferCounter > 0f && hasDoubleJumpUnlocked && canDoubleJump && !isGrounded && !isWallSliding)
            {
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, doubleJumpForce);

                if (AudioManager.Instance != null && doubleJumpSound != null) AudioManager.Instance.PlaySFX(doubleJumpSound, true);

                jumpBufferCounter = 0f;
                canDoubleJump = false;

                isDoubleJumping = true;
                doubleJumpAnimTimer = doubleJumpAnimDuration;

                if (doubleJumpEffectPrefab != null) SpawnEffect(doubleJumpEffectPrefab, transform, doubleJumpEffectOffset);
            }

            if (Input.GetKeyUp(jumpKey) && rb.linearVelocity.y > 0f)
            {
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, rb.linearVelocity.y * jumpCutMultiplier);
                coyoteTimeCounter = 0f;
            }

            if (moveInput != 0)
            {
                float direction = moveInput > 0 ? -1f : 1f;
                transform.localScale = new Vector3(baseScale.x * direction, baseScale.y, baseScale.z);
                wallJumpDirection = moveInput > 0 ? -1 : 1;
            }
        }
        else
        {
            wallJumpTimer -= Time.deltaTime;
            if (wallJumpTimer <= 0) isWallJumping = false;
        }

        ApplyBetterGravity();
        SetAnimation(moveInput);
    }

    public void UnlockDash()
    {
        hasDashUnlocked = true;
        if (upgradedAnimatorController != null) animator.runtimeAnimatorController = upgradedAnimatorController;
    }

    public void UnlockDoubleJump()
    {
        hasDoubleJumpUnlocked = true;
    }

    public void RechargeDash() { canDash = true; }

    public void SetRespawnPoint(Vector3 newPosition)
    {
        currentRespawnPosition = newPosition;
    }

    public void Die()
    {
        if (AudioManager.Instance != null && deathSound != null) AudioManager.Instance.PlaySFX(deathSound, false);

        if (deathEffectPrefab != null)
        {
            GameObject effect = Instantiate(deathEffectPrefab, transform.position, Quaternion.identity);
            Destroy(effect, 0.25f);
        }

        transform.position = currentRespawnPosition;
        Physics2D.SyncTransforms();

        rb.linearVelocity = Vector2.zero;
        canDash = false;

        if (CameraShake.Instance != null)
        {
            CameraShake.Instance.Shake(0.4f, 2f);
        }

        StartCoroutine(RespawnBlinkRoutine());
    }

    private System.Collections.IEnumerator RespawnBlinkRoutine()
    {
        yield return null;

        ShakingStone[] stones = Object.FindObjectsByType<ShakingStone>(FindObjectsSortMode.None);
        foreach (ShakingStone stone in stones) stone.ResetStone();

        StoneTriggerZone[] triggers = Object.FindObjectsByType<StoneTriggerZone>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (StoneTriggerZone trigger in triggers) trigger.ResetTrigger();

        FPlatform[] platforms = Object.FindObjectsByType<FPlatform>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (FPlatform platform in platforms) platform.ResetPlatform();

        float blinkSpeed = blinkDuration / (blinkCount * 2);

        for (int i = 0; i < blinkCount; i++)
        {
            spriteRenderer.enabled = false;
            yield return new WaitForSeconds(blinkSpeed);
            spriteRenderer.enabled = true;
            yield return new WaitForSeconds(blinkSpeed);
        }
        spriteRenderer.enabled = true;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Spikes")) Die();

        ShakingStone stone = collision.gameObject.GetComponent<ShakingStone>();
        if (stone != null && stone.IsCurrentlyFalling())
        {
            foreach (ContactPoint2D contact in collision.contacts)
            {
                if (contact.normal.y < -0.5f) { Die(); break; }
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Spikes")) Die();
    }

    private void HandleDash()
    {
        if (!hasDashUnlocked) return;

        if (isDashing)
        {
            dashTimeLeft -= Time.deltaTime;
            if (dashTimeLeft <= 0) { isDashing = false; rb.linearVelocity *= 0.2f; }
            return;
        }

        if (Input.GetKeyDown(dashKey) && canDash)
        {
            isDashing = true;
            canDash = false;
            dashTimeLeft = dashDuration;

            float xInput = Input.GetAxisRaw("Horizontal");
            float yInput = Input.GetAxisRaw("Vertical");
            dashDirection = new Vector2(xInput, yInput);

            if (dashDirection == Vector2.zero)
                dashDirection = new Vector2(transform.localScale.x < 0 ? 1f : -1f, 0f);

            dashDirection.Normalize();
            rb.linearVelocity = dashDirection * dashSpeed;
            animator.Play("PlayerDash");

            if (AudioManager.Instance != null && dashSound != null) AudioManager.Instance.PlaySFX(dashSound, true);

            SpawnEffect(dashEffectPrefab, transform, dashEffectOffset);
        }
    }

    private void HandleAttack()
    {
        if (attackTimer > 0)
        {
            attackTimer -= Time.deltaTime;
            if (attackTimer <= 0) isAttacking = false;
        }

        if (Input.GetKeyDown(attackKey) && attackTimer <= 0)
        {
            isAttacking = true;
            attackTimer = attackCooldown;
            float verticalInput = Input.GetAxisRaw("Vertical");

            if (verticalInput < 0 && !isGrounded)
            {
                animator.Play("PlayerAttackDown");

                if (AudioManager.Instance != null && attackSound != null) AudioManager.Instance.PlaySFX(attackSound, true);

                SpawnEffect(downAttackPrefab, downAttackPoint, downAttackOffset);
                DamageEnemies(downAttackPoint, downHitboxOffset, new Vector2(attackCapsuleSize.y, attackCapsuleSize.x), CapsuleDirection2D.Vertical, true);
            }
            else
            {
                animator.Play("PlayerAttack");

                if (AudioManager.Instance != null && attackSound != null) AudioManager.Instance.PlaySFX(attackSound, true);

                SpawnEffect(normalAttackPrefab, normalAttackPoint, normalAttackOffset);
                DamageEnemies(normalAttackPoint, normalHitboxOffset, attackCapsuleSize, capsuleDirection, false);
            }
        }
    }

    private void SpawnEffect(GameObject effectPrefab, Transform spawnPoint, Vector2 offset)
    {
        if (effectPrefab == null || spawnPoint == null) return;
        GameObject effect = Instantiate(effectPrefab, spawnPoint.position, Quaternion.identity, spawnPoint);
        effect.transform.localScale = new Vector3(
            effectPrefab.transform.localScale.x / Mathf.Abs(transform.localScale.x),
            effectPrefab.transform.localScale.y / Mathf.Abs(transform.localScale.y),
            effectPrefab.transform.localScale.z / Mathf.Abs(transform.localScale.z)
        );
        effect.transform.localPosition = new Vector3(-offset.x, offset.y, 0f);
        Destroy(effect, effectDuration);
    }

    private void DamageEnemies(Transform spawnPoint, Vector2 offset, Vector2 size, CapsuleDirection2D direction, bool isDownAttack)
    {
        if (spawnPoint == null) return;
        float currentDirX = Mathf.Sign(transform.localScale.x);
        Vector2 hitboxCenter = new Vector2(spawnPoint.position.x + (-offset.x * currentDirX), spawnPoint.position.y + offset.y);

        Collider2D[] hitEnemies = Physics2D.OverlapCapsuleAll(hitboxCenter, size, direction, 0f, enemyLayer);
        foreach (Collider2D enemy in hitEnemies)
            if (enemy.TryGetComponent(out Enemy e)) e.TakeDamage(attackDamage);

        if (isDownAttack)
        {
            Collider2D[] hitPogo = Physics2D.OverlapCapsuleAll(hitboxCenter, size, direction, 0f, pogoLayer);
            if (hitPogo.Length > 0)
            {
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, pogoForce);

                if (AudioManager.Instance != null && pogoSound != null) AudioManager.Instance.PlaySFX(pogoSound, true);

                canDoubleJump = true;
            }
        }
    }

    private void ApplyBetterGravity()
    {
        if (isClingingToStone || isDashing) return;
        if (isWallSliding) { rb.gravityScale = baseGravity; return; }

        if (rb.linearVelocity.y < 0)
        {
            rb.gravityScale = baseGravity * fallGravityMultiplier;
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, Mathf.Max(rb.linearVelocity.y, -maxFallSpeed));
        }
        else rb.gravityScale = baseGravity;
    }

    private void CheckWorld()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer);
        isTouchingWall = Physics2D.OverlapCircle(wallCheck.position, wallCheckRadius, wallLayer);
    }

    private void UpdateJumpCounters()
    {
        if (isGrounded)
        {
            coyoteTimeCounter = coyoteTime;
            canDoubleJump = true;
            canDash = false;
        }
        else coyoteTimeCounter -= Time.deltaTime;

        if (Input.GetKeyDown(jumpKey)) jumpBufferCounter = jumpBufferTime;
        else jumpBufferCounter -= Time.deltaTime;
    }

    private void WallSlideCheck(float moveInput)
    {
        isClingingToStone = false;
        if (isTouchingWall && !isGrounded && rb.linearVelocity.y <= 0.01f)
        {
            if (CheckIfShakingStone())
            {
                isWallSliding = true;
                isClingingToStone = true;
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0);
            }
            else if (moveInput != 0)
            {
                isWallSliding = true;
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, Mathf.Clamp(rb.linearVelocity.y, -wallSlidingSpeed, float.MaxValue));
            }
            else isWallSliding = false;
        }
        else isWallSliding = false;
    }

    private bool CheckIfShakingStone()
    {
        Collider2D[] hitColliders = Physics2D.OverlapCircleAll(wallCheck.position, wallCheckRadius, wallLayer);
        foreach (var collider in hitColliders)
            if (collider.GetComponent<ShakingStone>() != null) return true;
        return false;
    }

    private void HandleFallingWall(float moveInput)
    {
        bool foundFallingWall = false;
        Transform detectedWall = null;
        ShakingStone detectedStone = null;

        Collider2D[] hitWalls = Physics2D.OverlapCircleAll(wallCheck.position, wallCheckRadius, wallLayer);
        foreach (var collider in hitWalls)
        {
            ShakingStone stone = collider.GetComponent<ShakingStone>();
            if (stone != null && stone.IsCurrentlyFalling()) { detectedWall = collider.transform; detectedStone = stone; foundFallingWall = true; break; }
        }

        if (!foundFallingWall)
        {
            Collider2D[] hitGrounds = Physics2D.OverlapCircleAll(groundCheck.position, groundRadius, groundLayer);
            foreach (var collider in hitGrounds)
            {
                ShakingStone stone = collider.GetComponent<ShakingStone>();
                if (stone != null && stone.IsCurrentlyFalling()) { detectedWall = collider.transform; detectedStone = stone; foundFallingWall = true; break; }
            }
        }

        if (foundFallingWall)
        {
            if (!isOnFallingWall || currentFallingWall != detectedWall)
            {
                currentFallingWall = detectedWall;
                lastFallingWallPosition = currentFallingWall.position;
                currentStone = detectedStone;
                isOnFallingWall = true;
            }
            if (currentFallingWall != null)
            {
                Vector3 wallDelta = currentFallingWall.position - lastFallingWallPosition;
                if (wallDelta.y < 0) rb.MovePosition(rb.position + (Vector2)wallDelta);
                lastFallingWallPosition = currentFallingWall.position;
            }
        }
        else { isOnFallingWall = false; currentFallingWall = null; currentStone = null; }
    }

    private void WallJumpCheck()
    {
        if (jumpBufferCounter > 0f && isWallSliding)
        {
            isWallJumping = true;
            wallJumpTimer = wallJumpDuration;
            transform.localScale = new Vector3(-transform.localScale.x, transform.localScale.y, transform.localScale.z);
            rb.linearVelocity = new Vector2(wallJumpForce.x * wallJumpDirection, wallJumpForce.y);

            if (AudioManager.Instance != null && wallJumpSound != null) AudioManager.Instance.PlaySFX(wallJumpSound, true);

            jumpBufferCounter = 0f;
            coyoteTimeCounter = 0f;
            isOnFallingWall = false;
        }
    }

    private void SetAnimation(float moveInput)
    {
        if (isAttacking || isDashing || isDoubleJumping) return;
        if (isWallSliding) { animator.Play("WallSkelet"); return; }

        if (isGrounded)
        {
            if (Mathf.Abs(moveInput) < 0.1f) animator.Play("Playeridle");
            else animator.Play("PlayerRun");
        }
        else
        {
            if (rb.linearVelocity.y > 0) animator.Play("PlayerJump");
            else animator.Play("PlayerFall");
        }
    }

    public void StartEndingSequence(float upwardSpeed)
    {
        isEndingSequence = true;
        rb.gravityScale = 0f;
        rb.linearVelocity = new Vector2(0f, upwardSpeed);
        animator.Play("Playeridle");

        Collider2D col = GetComponent<Collider2D>();
        if (col != null) col.enabled = false;
    }

    void OnDrawGizmosSelected()
    {
        if (groundCheck != null) { Gizmos.color = Color.green; Gizmos.DrawWireSphere(groundCheck.position, groundRadius); }
        if (wallCheck != null) { Gizmos.color = isOnFallingWall ? Color.yellow : Color.red; Gizmos.DrawWireSphere(wallCheck.position, wallCheckRadius); }
        if (normalAttackPoint != null) { Gizmos.color = Color.cyan; Gizmos.DrawSphere(normalAttackPoint.position, 0.05f); }
        if (downAttackPoint != null) { Gizmos.color = Color.blue; Gizmos.DrawSphere(downAttackPoint.position, 0.05f); }

        float dirX = transform.localScale.x != 0 ? Mathf.Sign(transform.localScale.x) : 1;
        Gizmos.color = Color.red;
        if (normalAttackPoint != null)
        {
            Vector3 center = new Vector3(normalAttackPoint.position.x + (-normalHitboxOffset.x * dirX), normalAttackPoint.position.y + normalHitboxOffset.y, 0);
            Gizmos.DrawWireCube(center, attackCapsuleSize);
        }
        if (downAttackPoint != null)
        {
            Vector3 center = new Vector3(downAttackPoint.position.x + (-downHitboxOffset.x * dirX), downAttackPoint.position.y + downHitboxOffset.y, 0);
            Vector2 verticalSize = new Vector2(attackCapsuleSize.y, attackCapsuleSize.x);
            Gizmos.DrawWireCube(center, verticalSize);
        }
    }
}
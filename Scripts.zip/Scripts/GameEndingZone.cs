using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class GameEndingZone : MonoBehaviour
{
    [Header("Ending Settings")]
    public float floatSpeed = 2f;
    public float fadeDuration = 4f;
    public Image fadeImage;
    public string mainMenuSceneName = "MainMenu";

    private bool isTriggered = false;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!isTriggered && collision.CompareTag("Player"))
        {
            Player player = collision.GetComponent<Player>();
            if (player != null)
            {
                isTriggered = true;
                StartCoroutine(EndingRoutine(player));
            }
        }
    }

    private IEnumerator EndingRoutine(Player player)
    {
        player.StartEndingSequence(floatSpeed);

        if (fadeImage != null)
        {
            fadeImage.gameObject.SetActive(true);
            Color color = fadeImage.color;
            float elapsed = 0f;

            while (elapsed < fadeDuration)
            {
                elapsed += Time.deltaTime;
                color.a = Mathf.Lerp(0f, 1f, elapsed / fadeDuration);
                fadeImage.color = color;
                yield return null;
            }
        }
        else
        {
            yield return new WaitForSeconds(fadeDuration);
        }

        yield return new WaitForSeconds(0.5f);

        PlayerPrefs.SetInt("HasSave", 0);
        PlayerPrefs.SetInt("LoadFromSave", 0);
        PlayerPrefs.SetInt("DashUnlocked", 0);
        PlayerPrefs.SetInt("DoubleJumpUnlocked", 0);
        PlayerPrefs.DeleteKey("SaveX");
        PlayerPrefs.DeleteKey("SaveY");
        PlayerPrefs.Save();

        SceneManager.LoadScene(mainMenuSceneName);
    }
}
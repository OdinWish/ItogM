using UnityEngine;
using System.Collections;

public class FPlatform : MonoBehaviour
{
    [Header("Timing Settings")]
    public float delayBeforeFall = 2f;
    public float fadeDuration = 0.5f;
    public float respawnDelay = 3f;

    [Header("Shake Settings")]
    public float shakeIntensity = 0.05f;
    public float shakeSpeed = 40f;

    [Header("Fall Settings")]
    public float fallGravity = 1.5f;

    [Header("Audio Settings")]
    public AudioClip shakeSound;

    private Rigidbody2D rb;
    private Collider2D col;
    private SpriteRenderer spriteRenderer;

    private Vector3 startPosition;
    private Color startColor;

    private bool isTriggered = false;
    private bool isShaking = false;
    private float elapsedShakeTime = 0f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();

        startPosition = transform.position;
        if (spriteRenderer != null) startColor = spriteRenderer.color;

        InitPlatform();
    }

    private void InitPlatform()
    {
        isTriggered = false;
        isShaking = false;
        elapsedShakeTime = 0f;

        transform.position = startPosition;

        if (spriteRenderer != null)
        {
            spriteRenderer.enabled = true;
            Color c = spriteRenderer.color;
            c.a = startColor.a;
            spriteRenderer.color = c;
        }

        if (col != null) col.enabled = true;

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
            rb.linearVelocity = Vector2.zero;
            rb.constraints = RigidbodyConstraints2D.FreezeAll;
        }
    }

    void Update()
    {
        if (isShaking)
        {
            elapsedShakeTime += Time.deltaTime;
            float xOffset = Mathf.Sin(elapsedShakeTime * shakeSpeed) * shakeIntensity;
            transform.position = new Vector3(startPosition.x + xOffset, startPosition.y, startPosition.z);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!isTriggered && collision.gameObject.CompareTag("Player"))
        {
            if (collision.contacts[0].normal.y < -0.5f)
            {
                StartCoroutine(CollapseAndRespawnRoutine());
            }
        }
    }

    private IEnumerator CollapseAndRespawnRoutine()
    {
        isTriggered = true;
        isShaking = true;

        if (AudioManager.Instance != null && shakeSound != null)
        {
            AudioManager.Instance.PlaySFX(shakeSound, pitchShift: true);
        }

        yield return new WaitForSeconds(delayBeforeFall);

        isShaking = false;
        if (col != null) col.enabled = false;

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Dynamic;
            rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
            rb.gravityScale = fallGravity;
        }

        float elapsedFadeTime = 0f;
        while (elapsedFadeTime < fadeDuration)
        {
            elapsedFadeTime += Time.deltaTime;
            float normalizedTime = elapsedFadeTime / fadeDuration;

            if (spriteRenderer != null)
            {
                Color currentC = spriteRenderer.color;
                currentC.a = Mathf.Lerp(1f, 0f, normalizedTime);
                spriteRenderer.color = currentC;
            }
            yield return null;
        }

        if (spriteRenderer != null) spriteRenderer.enabled = false;

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
            rb.linearVelocity = Vector2.zero;
            rb.constraints = RigidbodyConstraints2D.FreezeAll;
        }
        transform.position = startPosition;

        yield return new WaitForSeconds(respawnDelay);
        InitPlatform();
    }

    public void ResetPlatform()
    {
        StopAllCoroutines();
        InitPlatform();
    }
}
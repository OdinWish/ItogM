using UnityEngine;
using System.Collections;

public class ShakingStone : MonoBehaviour
{
    [Header("Shake Settings")]
    public float shakeIntensity = 0.05f;
    public float shakeDuration = 0.5f;
    public float shakeSpeed = 30f;

    [Header("Fall Settings")]
    public float fallDelay = 0.5f;
    public float fallGravity = 2f;

    private Rigidbody2D rb;
    private Vector3 startPosition;
    private bool isShaking = false;
    private bool isFalling = false;
    private float shakeTimer = 0f;
    private float elapsedShakeTime = 0f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
            rb.constraints = RigidbodyConstraints2D.FreezeAll;
        }

        startPosition = transform.position;
    }

    void Update()
    {
        if (isShaking && !isFalling)
        {
            ShakeUpdate();
        }
    }

    public void ResetStone()
    {
        CancelInvoke("StartFalling");

        isShaking = false;
        isFalling = false;
        shakeTimer = 0f;
        elapsedShakeTime = 0f;

        transform.position = startPosition;

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
            rb.constraints = RigidbodyConstraints2D.FreezeAll;
            rb.linearVelocity = Vector2.zero;
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (!isShaking && !isFalling && collision.gameObject.CompareTag("Player"))
        {
            StartShaking();
        }
    }

    void OnCollisionStay2D(Collision2D collision)
    {
        if (!isShaking && !isFalling && collision.gameObject.CompareTag("Player"))
        {
            StartShaking();
        }
    }

    public void TriggerFall()
    {
        if (!isShaking && !isFalling)
        {
            StartShaking();
        }
    }

    void StartShaking()
    {
        isShaking = true;
        shakeTimer = shakeDuration;
        elapsedShakeTime = 0f;
        startPosition = transform.position;
        Invoke("StartFalling", fallDelay);
    }

    void ShakeUpdate()
    {
        elapsedShakeTime += Time.deltaTime;
        shakeTimer -= Time.deltaTime;

        float damping = shakeTimer / shakeDuration;
        float xOffset = Mathf.Sin(elapsedShakeTime * shakeSpeed) * shakeIntensity * damping;
        float yOffset = Mathf.Cos(elapsedShakeTime * shakeSpeed * 1.3f) * shakeIntensity * damping;

        transform.position = new Vector3(
            startPosition.x + xOffset,
            startPosition.y + yOffset,
            startPosition.z
        );

        if (shakeTimer <= 0)
        {
            isShaking = false;
            transform.position = startPosition;
        }
    }

    void StartFalling()
    {
        if (isFalling) return;

        isFalling = true;
        isShaking = false;

        transform.position = startPosition;

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Dynamic;
            rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
            rb.gravityScale = fallGravity;
            rb.linearVelocity = Vector2.zero;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        }
    }

    public bool IsCurrentlyFalling()
    {
        return isFalling && rb != null && rb.bodyType == RigidbodyType2D.Dynamic;
    }
}
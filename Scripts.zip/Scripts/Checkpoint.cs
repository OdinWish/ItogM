using UnityEngine;

public class Checkpoint : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent(out Player player))
        {
            player.SetRespawnPoint(transform.position);

            PlayerPrefs.SetFloat("SaveX", transform.position.x);
            PlayerPrefs.SetFloat("SaveY", transform.position.y);
            PlayerPrefs.SetInt("DashUnlocked", player.hasDashUnlocked ? 1 : 0);
            PlayerPrefs.SetInt("DoubleJumpUnlocked", player.hasDoubleJumpUnlocked ? 1 : 0);
            PlayerPrefs.SetInt("HasSave", 1);
            PlayerPrefs.Save();
        }
    }
}
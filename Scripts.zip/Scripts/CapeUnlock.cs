using UnityEngine;

public class CapeUnlock : MonoBehaviour
{
    void Start()
    {
        if (PlayerPrefs.GetInt("DashUnlocked", 0) == 1)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent(out Player player))
        {
            player.UnlockDash();
            player.UnlockDoubleJump();
            Destroy(gameObject);
        }
    }
}
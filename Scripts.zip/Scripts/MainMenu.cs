using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    public GameObject settingsPanel;
    public Button continueButton;

    [Header("Audio")]
    public AudioClip menuMusic;

    void Start()
    {
        if (AudioManager.Instance != null && menuMusic != null)
        {
            AudioManager.Instance.ChangeMusic(menuMusic, 1.0f);
        }

        if (PlayerPrefs.GetInt("HasSave", 0) == 0)
        {
            if (continueButton != null) continueButton.interactable = false;
        }
    }

    public void PlayNewGame()
    {
        PlayerPrefs.SetInt("LoadFromSave", 0);
        PlayerPrefs.Save();
        SceneManager.LoadScene("SampleScene");
    }

    public void ContinueGame()
    {
        PlayerPrefs.SetInt("LoadFromSave", 1);
        PlayerPrefs.Save();
        SceneManager.LoadScene("SampleScene");
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}